"""Sensoren voor EU Energy Live Prices."""
from __future__ import annotations

import logging
from typing import Any

from homeassistant.components.sensor import (
    SensorDeviceClass,
    SensorEntity,
    SensorStateClass,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity import EntityCategory
from homeassistant.helpers.entity_platform import AddEntitiesCallback
import homeassistant.util.dt as dt_util

from .const import DOMAIN
from .coordinator import EuEnergyLiveCoordinator
from .entity import EuEnergyLiveEntity

_LOGGER = logging.getLogger(__name__)

# (data-key, weergavenaam, icoon)
INFO_SENSORS: list[tuple[str, str, str]] = [
    ("zone", "Zone", "mdi:map-marker"),
    ("country", "Land", "mdi:flag"),
    ("currency", "Valuta", "mdi:currency-eur"),
    ("unit", "Eenheid (bron)", "mdi:ruler"),
    ("date", "Datum", "mdi:calendar"),
]


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Zet de sensor-entiteiten op."""
    coordinator: EuEnergyLiveCoordinator = hass.data[DOMAIN][entry.entry_id]

    entities: list[SensorEntity] = [
        EuEnergyInfoSensor(coordinator, entry, key, name, icon)
        for key, name, icon in INFO_SENSORS
    ]
    entities.append(EuEnergyLastRefreshSensor(coordinator, entry))

    # Eén sensor per uur van de dag (00 t/m 23), prijs in EUR/kWh.
    for hour in range(24):
        entities.append(EuEnergyHourPriceSensor(coordinator, entry, hour))

    async_add_entities(entities)


class _EuEnergyBaseEntity(EuEnergyLiveEntity, SensorEntity):
    """Basisklasse voor sensoren van deze integratie."""


class EuEnergyInfoSensor(_EuEnergyBaseEntity):
    """Referentie-sensor: zone, land, valuta, eenheid, datum."""

    _attr_entity_category = EntityCategory.DIAGNOSTIC

    def __init__(
        self,
        coordinator: EuEnergyLiveCoordinator,
        entry: ConfigEntry,
        key: str,
        name: str,
        icon: str,
    ) -> None:
        super().__init__(coordinator, entry)
        self._key = key
        self._attr_name = name
        self._attr_icon = icon
        self._attr_unique_id = f"{entry.entry_id}_{key}"

    @property
    def native_value(self) -> Any:
        if not self.coordinator.data:
            return None
        return self.coordinator.data.get(self._key)


class EuEnergyHourPriceSensor(_EuEnergyBaseEntity):
    """Prijs-sensor voor één specifiek uur van de dag, in EUR/kWh."""

    _attr_native_unit_of_measurement = "EUR/kWh"
    _attr_suggested_display_precision = 4
    _attr_state_class = SensorStateClass.MEASUREMENT
    _attr_icon = "mdi:cash"

    def __init__(
        self, coordinator: EuEnergyLiveCoordinator, entry: ConfigEntry, hour: int
    ) -> None:
        super().__init__(coordinator, entry)
        self._hour = hour
        self._attr_name = f"Prijs {hour:02d}:00"
        self._attr_unique_id = f"{entry.entry_id}_price_{hour:02d}"

    def _matching_entry(self) -> dict[str, Any] | None:
        """Zoek in coordinator.data['hours'] het item dat bij dit lokale uur hoort."""
        data = self.coordinator.data
        if not data:
            return None

        match: dict[str, Any] | None = None
        for item in data.get("hours", []):
            ts = dt_util.parse_datetime(item["ts"])
            if ts is None:
                continue
            local_ts = dt_util.as_local(ts)
            if local_ts.hour == self._hour:
                # Bij een tijdomschakeling (DST) kan een uur dubbel voorkomen;
                # in dat geval wordt het laatst gevonden item aangehouden.
                match = item
        return match

    @property
    def available(self) -> bool:
        return super().available and self._matching_entry() is not None

    @property
    def native_value(self) -> float | None:
        item = self._matching_entry()
        if item is None:
            return None
        price_mwh = item["price"]
        price_kwh = price_mwh / 1000
        return round(price_kwh, 4)

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        item = self._matching_entry()
        if item is None:
            return {}
        ts = dt_util.parse_datetime(item["ts"])
        return {
            "price_eur_mwh": item["price"],
            "utc_timestamp": item["ts"],
            "local_time": dt_util.as_local(ts).isoformat() if ts else None,
        }


class EuEnergyLastRefreshSensor(_EuEnergyBaseEntity):
    """Toont wanneer de data voor het laatst succesvol is ververst.

    Dit geldt zowel voor de automatische dagelijkse ophaalactie als voor
    een handmatige ververing via de "Refresh"-knop.
    """

    _attr_device_class = SensorDeviceClass.TIMESTAMP
    _attr_entity_category = EntityCategory.DIAGNOSTIC
    _attr_icon = "mdi:clock-check-outline"

    def __init__(self, coordinator: EuEnergyLiveCoordinator, entry: ConfigEntry) -> None:
        super().__init__(coordinator, entry)
        self._attr_name = "Laatste refresh"
        self._attr_unique_id = f"{entry.entry_id}_last_refresh"

    @property
    def native_value(self):
        return self.coordinator.last_refresh
