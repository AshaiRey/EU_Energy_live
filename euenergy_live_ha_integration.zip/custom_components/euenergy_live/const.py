"""Constanten voor de EU Energy Live Prices integratie."""

DOMAIN = "euenergy_live"

INTEGRATION_VERSION = "1.0.0"

CONF_EMAIL = "email"
CONF_LABEL = "label"
CONF_ZONE = "zone"
CONF_TOKEN = "token"
CONF_FETCH_TIME = "fetch_time"

DEFAULT_LABEL = "Home Assistant"
DEFAULT_ZONE = "NL"
DEFAULT_FETCH_TIME = "00:10:00"

API_BASE_URL = "https://euenergy.live/api/v1"
API_KEYS_URL = f"{API_BASE_URL}/keys"
API_PRICES_URL = f"{API_BASE_URL}/prices/today"

ATTRIBUTION = 'Data via euenergy.live (CC-BY-4.0). Attribution required.'
