"""Kleine API-client voor euenergy.live."""
from __future__ import annotations

import logging
from typing import Any

import aiohttp

from .const import API_KEYS_URL, API_PRICES_URL

_LOGGER = logging.getLogger(__name__)


class EuEnergyAuthError(Exception):
    """Token is ongeldig of verlopen."""


class EuEnergyApiError(Exception):
    """Algemene API-fout."""


async def async_request_token(
    session: aiohttp.ClientSession, email: str, label: str
) -> dict[str, Any]:
    """Vraag een nieuw token aan.

    Komt overeen met:
    curl -G "https://euenergy.live/api/v1/keys" -X POST \
        --data-urlencode "email=..." --data-urlencode "label=..."
    """
    try:
        async with session.post(
            API_KEYS_URL,
            data={"email": email, "label": label},
            timeout=aiohttp.ClientTimeout(total=30),
        ) as resp:
            if resp.status != 200:
                text = await resp.text()
                raise EuEnergyApiError(
                    f"Token-aanvraag mislukt ({resp.status}): {text}"
                )
            data = await resp.json()
            if "token" not in data:
                raise EuEnergyApiError(f"Onverwachte respons zonder token: {data}")
            return data
    except aiohttp.ClientError as err:
        raise EuEnergyApiError(f"Netwerkfout bij token-aanvraag: {err}") from err


async def async_fetch_prices(
    session: aiohttp.ClientSession, token: str, zone: str
) -> dict[str, Any]:
    """Haal de prijzen van vandaag op.

    Komt overeen met:
    curl "https://euenergy.live/api/v1/prices/today?zone=NL" \
        -H "Authorization: Bearer <token>"
    """
    headers = {"Authorization": f"Bearer {token}"}
    try:
        async with session.get(
            API_PRICES_URL,
            params={"zone": zone},
            headers=headers,
            timeout=aiohttp.ClientTimeout(total=30),
        ) as resp:
            if resp.status in (401, 403):
                raise EuEnergyAuthError(f"Token afgewezen ({resp.status})")
            if resp.status != 200:
                text = await resp.text()
                raise EuEnergyApiError(
                    f"Ophalen prijzen mislukt ({resp.status}): {text}"
                )
            return await resp.json()
    except aiohttp.ClientError as err:
        raise EuEnergyApiError(f"Netwerkfout bij ophalen prijzen: {err}") from err
