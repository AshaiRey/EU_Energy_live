"""EU Energy Live Prices integratie."""
from __future__ import annotations

import logging

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.event import async_track_time_change

from .const import CONF_FETCH_TIME, DEFAULT_FETCH_TIME, DOMAIN
from .coordinator import EuEnergyLiveCoordinator

_LOGGER = logging.getLogger(__name__)

PLATFORMS = ["sensor", "button"]


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Zet de config entry op."""
    coordinator = EuEnergyLiveCoordinator(hass, entry)

    # Eerste keer direct ophalen zodat er meteen data beschikbaar is
    # (bv. na herstart of eerste installatie), ook al is het niet het
    # ingestelde ophaalmoment.
    await coordinator.async_config_entry_first_refresh()

    hass.data.setdefault(DOMAIN, {})[entry.entry_id] = coordinator

    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)

    # Dagelijkse trigger op het door de gebruiker ingestelde tijdstip:
    # haalt de prijzen van vandaag op en ververst de sensoren.
    # Via Opties (achteraf aanpasbaar) heeft voorrang op de waarde die bij
    # installatie is gekozen.
    fetch_time = entry.options.get(
        CONF_FETCH_TIME, entry.data.get(CONF_FETCH_TIME, DEFAULT_FETCH_TIME)
    )
    hour, minute, second = (int(part) for part in fetch_time.split(":"))

    unsub = async_track_time_change(
        hass,
        lambda now: hass.async_create_task(coordinator.async_request_refresh()),
        hour=hour,
        minute=minute,
        second=second,
    )
    entry.async_on_unload(unsub)

    entry.async_on_unload(entry.add_update_listener(_async_update_listener))

    return True


async def _async_update_listener(hass: HomeAssistant, entry: ConfigEntry) -> None:
    """Herlaad de entry als de opties/config wijzigen."""
    await hass.config_entries.async_reload(entry.entry_id)


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Verwijder de config entry weer."""
    unload_ok = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    if unload_ok:
        hass.data[DOMAIN].pop(entry.entry_id)
    return unload_ok
