"""Refresh-knop voor EU Energy Live Prices."""
from __future__ import annotations

import logging

from homeassistant.components.button import ButtonEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import DOMAIN
from .coordinator import EuEnergyLiveCoordinator
from .entity import EuEnergyLiveEntity

_LOGGER = logging.getLogger(__name__)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Zet de Refresh-knop op."""
    coordinator: EuEnergyLiveCoordinator = hass.data[DOMAIN][entry.entry_id]
    async_add_entities([EuEnergyRefreshButton(coordinator, entry)])


class EuEnergyRefreshButton(EuEnergyLiveEntity, ButtonEntity):
    """Knop waarmee de gebruiker de data handmatig kan verversen."""

    _attr_icon = "mdi:refresh"

    def __init__(self, coordinator: EuEnergyLiveCoordinator, entry: ConfigEntry) -> None:
        super().__init__(coordinator, entry)
        self._attr_name = "Refresh"
        self._attr_unique_id = f"{entry.entry_id}_refresh"

    async def async_press(self) -> None:
        """Wordt aangeroepen als de gebruiker op de knop drukt."""
        _LOGGER.info("Handmatige refresh aangevraagd via de Refresh-knop")
        await self.coordinator.async_request_refresh()
