"""Gedeelde basisklasse voor EU Energy Live entiteiten."""
from __future__ import annotations

from homeassistant.config_entries import ConfigEntry
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import ATTRIBUTION, CONF_ZONE, DOMAIN, INTEGRATION_VERSION
from .coordinator import EuEnergyLiveCoordinator


class EuEnergyLiveEntity(CoordinatorEntity[EuEnergyLiveCoordinator]):
    """Basisklasse met gedeelde attributie en device-info."""

    _attr_attribution = ATTRIBUTION
    _attr_has_entity_name = True

    def __init__(self, coordinator: EuEnergyLiveCoordinator, entry: ConfigEntry) -> None:
        super().__init__(coordinator)
        self._entry = entry
        zone = entry.data[CONF_ZONE]
        self._attr_device_info = {
            "identifiers": {(DOMAIN, entry.entry_id)},
            "name": f"EU Energy Live ({zone})",
            "model": "Day-ahead prices via euenergy.live",
            "manufacturer": "AvZ",
            "sw_version": INTEGRATION_VERSION,
        }
