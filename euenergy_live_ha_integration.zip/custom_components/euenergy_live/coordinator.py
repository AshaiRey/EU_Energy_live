"""Coordinator die de prijzen ophaalt bij euenergy.live."""
from __future__ import annotations

import logging
from datetime import datetime
from typing import Any

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed
import homeassistant.util.dt as dt_util

from .api import (
    EuEnergyApiError,
    EuEnergyAuthError,
    async_fetch_prices,
    async_request_token,
)
from .const import CONF_EMAIL, CONF_LABEL, CONF_TOKEN, CONF_ZONE, DOMAIN

_LOGGER = logging.getLogger(__name__)


class EuEnergyLiveCoordinator(DataUpdateCoordinator[dict[str, Any]]):
    """Haalt de dagprijzen op en ververst het token indien nodig.

    De coordinator wordt getriggerd via de dagelijkse, door de gebruiker
    ingestelde tijd-trigger in __init__.py, en daarnaast handmatig via de
    "Refresh"-knop. update_interval staat bewust op None: er is geen vaste
    polling-interval, alleen deze twee triggers.
    """

    def __init__(self, hass: HomeAssistant, entry: ConfigEntry) -> None:
        super().__init__(
            hass,
            _LOGGER,
            name=DOMAIN,
            update_interval=None,
        )
        self.entry = entry
        self.last_refresh: datetime | None = None

    @property
    def _zone(self) -> str:
        return self.entry.data[CONF_ZONE]

    async def _async_update_data(self) -> dict[str, Any]:
        session = async_get_clientsession(self.hass)
        token = self.entry.data[CONF_TOKEN]

        try:
            try:
                data = await async_fetch_prices(session, token, self._zone)
            except EuEnergyAuthError:
                # Token is verlopen/ongeldig -> automatisch een nieuw token
                # aanvragen met de opgeslagen email/label en opnieuw proberen.
                _LOGGER.info(
                    "euenergy.live token verlopen of ongeldig, nieuw token aanvragen"
                )
                token_result = await async_request_token(
                    session,
                    self.entry.data[CONF_EMAIL],
                    self.entry.data[CONF_LABEL],
                )
                token = token_result["token"]

                new_data = dict(self.entry.data)
                new_data[CONF_TOKEN] = token
                self.hass.config_entries.async_update_entry(
                    self.entry, data=new_data
                )

                data = await async_fetch_prices(session, token, self._zone)
        except (EuEnergyApiError, EuEnergyAuthError) as err:
            raise UpdateFailed(f"Fout bij ophalen euenergy.live data: {err}") from err

        # Tijdstip van deze succesvolle refresh vastleggen (automatisch of
        # via de handmatige Refresh-knop maakt hier geen verschil).
        self.last_refresh = dt_util.utcnow()

        return data
