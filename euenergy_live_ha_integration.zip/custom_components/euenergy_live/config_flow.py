"""Config flow voor EU Energy Live Prices."""
from __future__ import annotations

import logging
from typing import Any

import voluptuous as vol

from homeassistant import config_entries
from homeassistant.core import HomeAssistant
from homeassistant.helpers import selector
from homeassistant.helpers.aiohttp_client import async_get_clientsession

from .api import EuEnergyApiError, async_request_token
from .const import (
    CONF_EMAIL,
    CONF_FETCH_TIME,
    CONF_LABEL,
    CONF_TOKEN,
    CONF_ZONE,
    DEFAULT_FETCH_TIME,
    DEFAULT_LABEL,
    DEFAULT_ZONE,
    DOMAIN,
)

_LOGGER = logging.getLogger(__name__)

STEP_USER_SCHEMA = vol.Schema(
    {
        vol.Required(CONF_EMAIL): str,
        vol.Required(CONF_LABEL, default=DEFAULT_LABEL): str,
        vol.Required(CONF_ZONE, default=DEFAULT_ZONE): str,
        vol.Required(
            CONF_FETCH_TIME, default=DEFAULT_FETCH_TIME
        ): selector.TimeSelector(),
    }
)


class EuEnergyLiveConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    """Config flow: vraagt email + label uit en haalt daarmee direct een token op."""

    VERSION = 1

    async def async_step_user(
        self, user_input: dict[str, Any] | None = None
    ) -> config_entries.ConfigFlowResult:
        errors: dict[str, str] = {}

        if user_input is not None:
            email = user_input[CONF_EMAIL]
            label = user_input[CONF_LABEL]
            zone = user_input[CONF_ZONE].upper()
            fetch_time = user_input[CONF_FETCH_TIME]

            await self.async_set_unique_id(f"{email}_{label}_{zone}")
            self._abort_if_unique_id_configured()

            session = async_get_clientsession(self.hass)
            try:
                result = await async_request_token(session, email, label)
            except EuEnergyApiError as err:
                _LOGGER.error("Kon geen token ophalen: %s", err)
                errors["base"] = "cannot_connect"
            else:
                token = result["token"]
                return self.async_create_entry(
                    title=f"EU Energy Live ({zone})",
                    data={
                        CONF_EMAIL: email,
                        CONF_LABEL: label,
                        CONF_ZONE: zone,
                        CONF_TOKEN: token,
                        CONF_FETCH_TIME: fetch_time,
                    },
                )

        return self.async_show_form(
            step_id="user", data_schema=STEP_USER_SCHEMA, errors=errors
        )

    @staticmethod
    def async_get_options_flow(
        config_entry: config_entries.ConfigEntry,
    ) -> EuEnergyLiveOptionsFlow:
        """Geef de opties-flow terug waarmee het ophaaltijdstip achteraf wijzigbaar is."""
        return EuEnergyLiveOptionsFlow()


class EuEnergyLiveOptionsFlow(config_entries.OptionsFlow):
    """Opties-flow: hiermee kan het dagelijkse ophaaltijdstip achteraf worden aangepast.

    Let op: sinds Home Assistant 2024.12 is `self.config_entry` een
    read-only property die de basisklasse zelf al invult. Deze NIET zelf
    instellen in __init__ (dat geeft een AttributeError / 500-fout in de
    UI) — gewoon direct gebruiken.
    """

    async def async_step_init(
        self, user_input: dict[str, Any] | None = None
    ) -> config_entries.ConfigFlowResult:
        if user_input is not None:
            return self.async_create_entry(title="", data=user_input)

        current_fetch_time = self.config_entry.options.get(
            CONF_FETCH_TIME,
            self.config_entry.data.get(CONF_FETCH_TIME, DEFAULT_FETCH_TIME),
        )
        schema = vol.Schema(
            {
                vol.Required(
                    CONF_FETCH_TIME, default=current_fetch_time
                ): selector.TimeSelector(),
            }
        )
        return self.async_show_form(step_id="init", data_schema=schema)
